var myJSON = [
    {
        "codigo" : "001",
        "nombre" : "Virginia"
    },
    {
        "codigo" : "002",
        "nombre" : "Andrés"
    },
    {
        "codigo" : "003",
        "nombre" : "John"
    }
];

function leerJSON(json) {
    var out = "";
    var i;
    for(i = 0; i<json.lenght; i++){
        out += document.getElementById("datos").innerHTML = "Código: " + json[i].codigo + "Nombre: " + json[i].nombre + "<br>";
    }
}
leerJSON(myJSON);

